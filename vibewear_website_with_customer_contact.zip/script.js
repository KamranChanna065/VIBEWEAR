const bag=[];const count=document.getElementById('bagCount'),bagEl=document.getElementById('bag'),overlay=document.getElementById('overlay'),items=document.getElementById('bagItems'),sub=document.getElementById('subtotal');
function render(){count.textContent=bag.length;if(!bag.length){items.innerHTML='<p>Your bag is empty.</p>';sub.textContent='PKR 0';return}items.innerHTML=bag.map((p,i)=>`<div class="bagrow"><span>${p.name}</span><strong>PKR ${p.price.toLocaleString()}</strong><button onclick="removeItem(${i})">×</button></div>`).join('');sub.textContent='PKR '+bag.reduce((a,p)=>a+p.price,0).toLocaleString()}
function removeItem(i){bag.splice(i,1);render()}function openBag(){bagEl.classList.add('open');overlay.classList.add('show')}function closeBag(){bagEl.classList.remove('open');overlay.classList.remove('show')}
document.querySelectorAll('.add').forEach(b=>b.onclick=()=>{let p=b.closest('.product');bag.push({name:p.dataset.name,price:+p.dataset.price});render();openBag()});
document.getElementById('bagBtn').onclick=openBag;document.getElementById('closeBag').onclick=closeBag;overlay.onclick=closeBag;
document.getElementById('menuBtn').onclick=()=>document.getElementById('nav').classList.toggle('mobile');document.querySelectorAll('nav a').forEach(a=>a.onclick=()=>document.getElementById('nav').classList.remove('mobile'));
const s=document.getElementById('searchbar');document.getElementById('searchBtn').onclick=()=>{s.classList.add('open');document.getElementById('searchInput').focus()};document.getElementById('closeSearch').onclick=()=>s.classList.remove('open');
document.getElementById('searchInput').oninput=e=>{let q=e.target.value.toLowerCase();document.querySelectorAll('.product').forEach(p=>p.style.display=p.dataset.name.toLowerCase().includes(q)?'block':'none')};
document.getElementById('newsletter').onsubmit=e=>{e.preventDefault();alert('Welcome to VibeWear!');e.target.reset()};document.getElementById('checkout').onclick=()=>alert(bag.length?'Connect this button to your real checkout/payment system.':'Your bag is empty.');render();

// Contact form: replace the placeholder below with the Gmail address that should receive customer messages.
const VIBEWEAR_CONTACT_EMAIL = 'YOUR-GMAIL-HERE@gmail.com';
const contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', (event) => {
    event.preventDefault();
    if (VIBEWEAR_CONTACT_EMAIL.includes('YOUR-GMAIL-HERE')) {
      alert('Please add your VibeWear receiving Gmail in script.js first.');
      return;
    }
    const name = document.getElementById('contactName').value.trim();
    const email = document.getElementById('contactEmail').value.trim();
    const message = document.getElementById('contactMessage').value.trim();
    const subject = encodeURIComponent(`VibeWear customer message from ${name}`);
    const body = encodeURIComponent(`Name: ${name}\nCustomer email: ${email}\n\nMessage:\n${message}`);
    window.location.href = `mailto:${VIBEWEAR_CONTACT_EMAIL}?subject=${subject}&body=${body}`;
  });
}
