VIBEWEAR COMPLETE WEBSITE

This version uses a stronger editorial/streetwear image direction with varied campaign, lifestyle and product visuals.

SEO included:
- SEO title, meta description and keywords
- Canonical URL
- Open Graph and Twitter metadata
- Organization and WebSite structured data
- FAQPage structured data
- Descriptive image alt/title text
- Lazy-loaded below-the-fold images
- robots.txt and sitemap.xml
- Semantic headings and navigation

Before launch:
1. Replace vibewear.pk with your real domain.
2. Replace demo images with your own licensed/product photography.
3. Replace social links, email and product details.
4. Add real size guide, returns and shipping policy.
5. Connect checkout/payment/order management.
6. Submit sitemap.xml to Google Search Console.

The bag/search are front-end demo interactions only; no real payment is processed.


CONTACT FORM
The site now includes a VibeWear customer contact form with a relevant streetwear image. Open script.js and replace YOUR-GMAIL-HERE@gmail.com with the Gmail address that should receive customer messages. The form uses the visitor's email app (mailto) to prepare the message; it does not store passwords or require your Gmail login.
